package org.example;

import org.openjdk.jmh.annotations.*;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Thread)
@Fork(1)
public class MatrixMultiplicationBenchmarking {

	@Param({"1", "2", "3", "4"})
	private int numThreads;

	@State(Scope.Thread)
	public static class Operands {
		private final int n = 2048
				;
		private final double[][] a = new double[n][n];
		private final double[][] b = new double[n][n];

		@Setup
		public void setup() {
			Random random = new Random();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					a[i][j] = random.nextDouble();
					b[i][j] = random.nextDouble();
				}
			}
		}
	}
	@State(Scope.Thread)
	public static class ResourceUsage {
		long totalMemoryUsed = 0;
		double totalCpuPercentageUsed = 0;
		int iterations = 0;

		public void accumulate(long memoryUsed, double cpuPercentageUsed) {

			totalMemoryUsed += memoryUsed;
			totalCpuPercentageUsed += cpuPercentageUsed;
			iterations++;
		}

		@TearDown
		public void printAverages() {
			if (iterations > 0) {
				double averageMemoryUsageMB = (double) totalMemoryUsed / iterations;
				double averageCpuPercentageUsed =  totalCpuPercentageUsed / iterations;
				System.out.println("Average Memory Usage: " + averageMemoryUsageMB + " MB");
				System.out.println("CPU Usage Percentage: " + averageCpuPercentageUsed + " %");
			}
		}

	}

	@Warmup(iterations = 1, time = 1, timeUnit = TimeUnit.SECONDS)
	@Measurement(iterations = 5, time = 1, timeUnit = TimeUnit.SECONDS)
	@Benchmark
	public void multiplication(Operands operands, ResourceUsage resourceUsage) {
		int tileSize = 32; // Rozmiar kafla
		new MatrixMultiplication(tileSize, numThreads).execute(operands.a, operands.b);
		double cpu = getProcessCpuLoad();
		long memory =getUsedMemory()/ (1024 * 1024);
//		System.out.println("Memory Usage: " + memory  + " MB");
//		System.out.println("CPU Usage: " + cpu + "%");
		resourceUsage.accumulate(memory, cpu);
	}
	private double getProcessCpuLoad() {
		OperatingSystemMXBean osBean = ManagementFactory.getOperatingSystemMXBean();
		if (osBean instanceof com.sun.management.OperatingSystemMXBean) {
			return ((com.sun.management.OperatingSystemMXBean) osBean).getProcessCpuLoad() * 100;
		}
		return -1;
	}

	private long getUsedMemory() {
		Runtime runtime = Runtime.getRuntime();
		return runtime.totalMemory() - runtime.freeMemory();
	}
}
