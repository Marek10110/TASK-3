package org.example;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MatrixMultiplication {

	private final int tileSize;
	private final int numThreads;

	public MatrixMultiplication(int tileSize, int numThreads) {
		this.tileSize = tileSize;
		this.numThreads = numThreads;
	}

	public double[][] execute(double[][] a, double[][] b) {
		int n = a.length;
		assert n == b.length;
		double[][] c = new double[n][n];

		ExecutorService executor = Executors.newFixedThreadPool(numThreads);

		for (int i = 0; i < n; i += tileSize) {
			for (int j = 0; j < n; j += tileSize) {
				for (int k = 0; k < n; k += tileSize) {
					int finalI = i;
					int finalJ = j;
					int finalK = k;
					executor.submit(() -> multiplyTile(a, b, c, finalI, finalJ, finalK));
				}
			}
		}

		executor.shutdown();
		try {
			if (!executor.awaitTermination(1, TimeUnit.HOURS)) {
				throw new RuntimeException("Nie udało się zakończyć wszystkich wątków w odpowiednim czasie!");
			}
		} catch (InterruptedException e) {
			throw new RuntimeException("Wątki zostały przerwane!", e);
		}

		return c;
	}

	private void multiplyTile(double[][] a, double[][] b, double[][] c, int row, int col, int inner) {
		int n = a.length;
		for (int i = row; i < Math.min(row + tileSize, n); i++) {
			for (int j = col; j < Math.min(col + tileSize, n); j++) {
				for (int k = inner; k < Math.min(inner + tileSize, n); k++) {
					c[i][j] += a[i][k] * b[k][j];
				}
			}
		}
	}
}
